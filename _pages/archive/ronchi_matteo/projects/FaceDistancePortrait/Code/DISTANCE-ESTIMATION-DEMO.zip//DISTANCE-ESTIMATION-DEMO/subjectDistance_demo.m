%
%% LICENSE
% 
% Copyright 2014:
%   - Xavier P.Burgos-Artizzu [xavier.burgos@technicolor.com]
%   - Matteo Ruggero Ronchi   [mronchi@caltech.edu]
%   - Pietro Perona           [perona@caltech.edu]
% Please email us if you find bugs, or have suggestions or questions!
% Licensed under the Simplified BSD License [see bsd.txt]
%
%% DESCRIPTION
%
% Version [1.0.0]
%
% This script runs an experiment with the parameters provided as input,
% returns the results of experiment and visualizes them.
%
% - taskName:   
%           REGRESSION (gives an estimate of the distance for all 
%           subjects in the Test Set) or REORDERING (orders a random 
%           permutation of all the subjects in the Test Set)
%
% - annotation_type:
%           decides which keypoints to use for the above task. To be
%           selected among MANUAL_ST, RCPR_CMDP_ST, RCPR_300F_ST
%
% - feature_norm:
%           selects which normalization scheme will be used to nomalize the
%           features. 'subject_shape' is the standard in the REORDERING
%           task, for REGRESSION user can choose between 'global_mean' and
%           'distance_shape'
%
% - keypoint_group:
%           we divided the 55 or 68 keypoints measured around the face into
%           9 differrent groups: {mouth,nose,ears,leye,reye,leyebrow,
%           reyebros, facial contour, head contour}. An experiment can be 
%           run by combining multiple of these groups as features vector
%
% - distance_type:
%           regression can be either on the distance at which a picture
%           was taken ('NORMAL') or on the inverse distance ('INVERSE')
%           allowing less signal saturation and overall best performance
%           
% - distance_number:
%           it's possible to select the number of distances on which
%           perform the regression (3,4,5near,5far,7)
%
% - remove_subjects:
%           specific subjects can be removed from the dataset based on
%           their physical appearance (i.e. men, women, occluded_ears,
%           with_beard)
%
% - training_ratio:
%           select ratio of images in the dataset to use for training and
%           for testing. Note that in the case of RCPR_CMDP_ST features the
%           ratio is fixed to .7 (37 subjects in training, 16 in test)
%           because the RCPR_CMDP_ST features were computed only for 16
%           subjects. This will soon be extended.
%
% - DINFO_PATH: 
%           location of the dataset struct on the file system

clear;clc;

%% CONFIGURE PATH VARIABLE
DINFO_PATH = './';
load([DINFO_PATH 'dinfo.mat']);

%% CONFIGURE MAIN PARAMETERS OF SIMULATION
taskName = 'REGRESSION';%'REGRESSION';%'REORDERING'

annotation_type = 'MANUAL_ST';%'RCPR_CMDP_ST';%'RCPR_300F_ST';

feature_norm = 'distance_shape';%'global_mean','subject_shape'

keypoint_group = 'hc+nose';%check function featureSelection in 
                    %performDistanceEstimation function for all 29 options.
                    
distance_type = 'INVERSE';%'NORMAL'

distance_number = '7';%'3';'4';'5near','5far'

remove_subjects = 'none';%'women','men','occluded_ears','with_beard'

training_ratio = .7; %[.1 .2 .5 .6 .7 .8 1]

% Few constraints in the simulation that are enforced
if (strcmp(annotation_type,'RCPR_CMDP_ST') && training_ratio ~= .7)
    training_ratio = .7;
    fprintf(1,['\nChanging training ratio to [0.7].\n' ...
        'In this version of code RCPR_CMDP annotations need a fixed'...
        ' training set with 37 subjects and test set with 16.\n\n']);
end
if (strcmp(taskName,'REORDERING') && ~strcmp(feature_norm,'subject_shape'))
    feature_norm = 'subject_shape';
    fprintf(1,['\nChanging feature normalization to [subject_shape].\n' ...
        'In the reordering task we are allowed to compute subject'...
        ' tuned feature normalization.\n\n']);
end

%% STRUCT CONTAINING PARAMETERS OF SIMULATION
prmStruct = struct( ...
    'annotation_type', annotation_type, ...
    'keypoint_group', keypoint_group, ...
    'feature_norm', feature_norm, ...
    'distance_type', distance_type, ...
    'distance_number', distance_number, ...
    'remove_subjects', remove_subjects, ...
    'training_ratio', training_ratio ...
);

%% TASK COMPUTATION
allCVRuns = performDistanceEstimation( prmStruct, DINFO_PATH );

%% RESULTS VISUALIZATION

emptyCells = cellfun( @isempty, allCVRuns );
N_RUNS = length( allCVRuns ) - sum( emptyCells );

N_IMAGES_TEST = numel( allCVRuns{1}.labelsTest );
N_PICS = allCVRuns{1}.N_PICS;

test_idxs = allCVRuns{1}.test_idxs;

% vector with original labels
y = zeros( N_RUNS, N_IMAGES_TEST );
% vector with results of regression
y_fit = zeros( N_RUNS, N_IMAGES_TEST );

for s = 1:N_RUNS

    N_SUBJ_TEST = N_IMAGES_TEST / N_PICS;

    labelsTest = reshape( allCVRuns{s}.labelsTest, ...
                            N_SUBJ_TEST, N_PICS );
    resultsTest = reshape( allCVRuns{s}.resultsTest, ...
                            N_SUBJ_TEST, N_PICS );

    y( s, : ) = labelsTest(:)';
    y_fit( s, : ) = resultsTest(:)';

end

fprintf(1,'\nResults over all the runs:\n');

% PEARSON CORRELATION COEFFICIENT
corr_Coeff = corr( y(:), y_fit(:) )

% R2 COEFFICIENT
SSres = sum( ( y(:) - y_fit(:) ).^2 );
SStot = sum( ( y(:) - mean(y(:)) ).^2);
r2_Coeff = 1 - SSres / SStot

switch taskName
    case 'REGRESSION'
        fprintf(1,'\nShowing results for the REGRESSION task\n');
        
        y_fit_avg = mean( y_fit );
        y_fit_avg = reshape( y_fit_avg, N_SUBJ_TEST, N_PICS );
        
        switch distance_type
            case 'NORMAL'
                dist_avg = y_fit_avg;
                labels = distancesVec_FT;
            case 'INVERSE'
                dist_avg = y_fit_avg;
                labels = 1 ./ distancesVec_FT;
        end
        
        figure(1);clf;
        
        for i = 1:N_SUBJ_TEST
           for j = 1:N_PICS
            
               subplot( 1, N_PICS, j );
               switch distance_number
                   case '3'
                       kept_distances=[1 4 7];

                   case '4'
                       kept_distances=[1 3 5 7];

                   case '5near'
                       kept_distances=[1 2 3 5 7];

                   case '5far'
                       kept_distances=[1 3 5 6 7];

                   case '7'
                       kept_distances=1:7;
               end
               
               switch annotation_type
                   case 'MANUAL_ST'
                       img = imread( ...
                              imagePaths_Manual_ST{ test_idxs(i), ...
                                                    kept_distances(j) ...
                                                   } ...
                            );
                   case 'RCPR_CMDP_ST'
                       img = imread( ...
                              imagePaths_RcprCMDP_ST{ test_idxs(i), ...
                                                    kept_distances(j) ...
                                                   } ...
                            );
                   case 'RCPR_300F_ST'
                       img = imread( ...
                              imagePaths_Rcpr300F_ST{ test_idxs(i), ...
                                                    kept_distances(j) ...
                                                   } ...
                            );
               end
               
               imshow(img);
               title( sprintf( 'Y:[%s]\nTrue Y:[%s]', ...
                    num2str(dist_avg(i,j)), ...
                    num2str(labels(kept_distances(j))) ) );
               
           end
           
           if i == 1
               fprintf('\nPress any key for the next subject\n');
           end
           pause();
        end
        
    case 'REORDERING'
        fprintf(1,'\nShowing results for the REORDERING task\n');
        
        y_fit_avg = mean( y_fit );
        y_fit_avg = reshape( y_fit_avg, N_SUBJ_TEST, N_PICS );
        
        switch distance_type
            case 'NORMAL'
                dist_avg = y_fit_avg;
                labels = distancesVec_FT;
            case 'INVERSE'
                dist_avg = y_fit_avg;
                labels = 1 ./ distancesVec_FT;
        end
        
        figure(1);clf;
        
        for i = 1:N_SUBJ_TEST
            
           [~,pos] = sort(dist_avg(i,:),'descend');
           for j = 1:N_PICS
            
               subplot( 1, N_PICS, j );
               switch distance_number
                   case '3'
                       kept_distances=[1 4 7];

                   case '4'
                       kept_distances=[1 3 5 7];

                   case '5near'
                       kept_distances=[1 2 3 5 7];

                   case '5far'
                       kept_distances=[1 3 5 6 7];

                   case '7'
                       kept_distances=1:7;
               end
               
               switch annotation_type
                   case 'MANUAL_ST'
                       img = imread( ...
                              imagePaths_Manual_ST{ test_idxs(i), ...
                                                    kept_distances(j) ...
                                                   } ...
                            );
                   case 'RCPR_CMDP_ST'
                       img = imread( ...
                              imagePaths_RcprCMDP_ST{ test_idxs(i), ...
                                                    kept_distances(j) ...
                                                   } ...
                            );
                   case 'RCPR_300F_ST'
                       img = imread( ...
                              imagePaths_Rcpr300F_ST{ test_idxs(i), ...
                                                    kept_distances(j) ...
                                                   } ...
                            );
               end
               
               imshow(img);
               title( sprintf( 'Pos:[%s]\nTrue Pos:[%s]', ...
                   num2str(pos(j)), num2str(j) ) );
               
           end
           if i == 1
               fprintf('\nPress any key for the next subject\n');
           end
           pause();
        end
        
end

