%
%% LICENSE
% 
% Copyright 2014:
%   - Xavier P.Burgos-Artizzu [xavier.burgos@technicolor.com]
%   - Matteo Ruggero Ronchi   [mronchi@caltech.edu]
%   - Pietro Perona           [perona@caltech.edu]
% Please email us if you find bugs, or have suggestions or questions!
% Licensed under the Simplified BSD License [see bsd.txt]
%
%% DESCRIPTION
%
% Version [1.0.0]
%
% This function runs an experiment with the parameters specificed by the
% user.
%
%% INPUT
%
% - prmStruct:
%           struct containing all the parameters of the experiment to run
%
% - DINFO_PATH: 
%           location of the dataset struct on the file system.
%
%% OUTPUT
%
% - out: 
%           a cell array containing the results of computation for each run
%           in the cross validation routine

function [ out ] = performDistanceEstimation( prmStruct, DINFO_PATH )


%% LOAD DATA AND EXPERIMENT PARAMETERS
annotation_type = prmStruct.annotation_type;
keypoint_group = prmStruct.keypoint_group;
feature_norm = prmStruct.feature_norm;
distance_type = prmStruct.distance_type;
distance_number = prmStruct.distance_number;
remove_subjects = prmStruct.remove_subjects;
training_ratio = prmStruct.training_ratio;

fprintf('\nRUNNING performDitstanceEstimation with parameters: \n');

structNames = fieldnames(prmStruct);
N_PRM = length(structNames);
for i = 1:N_PRM
    if ~isnumeric(prmStruct.(structNames{i}))
        fprintf('\t- [%s]:\t\t[%s] \n', structNames{i}, ...
            prmStruct.(structNames{i}));
    else
        fprintf('\t- [%s]:\t\t[%s] \n', structNames{i}, ...
            num2str(prmStruct.(structNames{i})));
    end
end

load([DINFO_PATH 'dinfo.mat']);

%% REMOVE SUBJECTS FROM DATASET BASED ON APPEARANCE, ETHNICITY, GENDER
kept_subjects_idxs = removeSubjects( remove_subjects, infos );

%% KEEP ONLY SOME OF THE DISTANCES AT WHICH SUBJECTS WERE TAKEN
kept_distances = selectDistanceNumber( distance_number );

%% REMOVE KEYPOINT GROUPS
kept_fids_idxs = featureSelection( annotation_type, keypoint_group );

%% SELECT FEATURES ANNOTATION TYPE
switch annotation_type

    case 'MANUAL_ST'
        fids = fids_Manual_ST;
    case 'RCPR_CMDP_ST'
        fids = fids_RcprCMDP_ST;
    case 'RCPR_300F_ST'
        fids = fids_Rcpr300F_ST;
end

fids = fids( kept_subjects_idxs, kept_fids_idxs, kept_distances );

%% BUILD MATRIX CONTAINING CLASSIFICATION LABELS OF PICTURES IN THE DATASET
LABELS_MATRIX = repmat(distancesVec_FT, numSubjects, 1);
LABELS_MATRIX = LABELS_MATRIX( kept_subjects_idxs, kept_distances );

%% KEEP NORMAL DISTANCE LABELS OR INVERT THEM
if( strcmp( distance_type, 'INVERSE') )
    LABELS_MATRIX = 1 ./ LABELS_MATRIX;
end

%% EXPERIMENT CONSTANTS
[N_SUBJ, N_MEASUREMENTS, N_PICS] = size( fids );

%% CROSS-VALIDATION LOOP
do_CV = ~strcmp( annotation_type, 'RCPR_CMDP_ST' );
if do_CV
    if training_ratio == 1
        N_RUNS = N_SUBJ;
    else
        N_RUNS = 20;
    end
else
    N_RUNS = 1;
end

% allocate space for results variable
allCVRuns = cell(1,N_RUNS);

for s = 1:N_RUNS

    %% BUILD TRAINING AND TEST SETS
    if do_CV 
        if training_ratio == 1 
            % Train on all but one, test on the remaining
            training_idxs = [ 1:s-1 s+1:N_SUBJ ]; 
            test_idxs = s;
            N_TRAIN_IMAGES = ( N_SUBJ - 1 ) * N_PICS;
            N_TEST_IMAGES = N_PICS;
        else
            % Train on training_ratio percent, test on the remaining
            all = 1:N_SUBJ;
            NTrain = round( training_ratio * N_SUBJ );
            training_idxs = randSample( all, NTrain );
            test_idxs = all( ~ismember( all, training_idxs ) );
            N_TRAIN_IMAGES = NTrain * N_PICS;
            N_TEST_IMAGES = ( N_SUBJ - NTrain ) * N_PICS;
        end
    else
        training_idxs = trainSub;
        test_idxs = testSub;
        N_TRAIN_IMAGES = length( training_idxs ) * N_PICS;
        N_TEST_IMAGES = length( test_idxs ) * N_PICS;        
    end
    
    % Set fiducials
    fidsTrain = fids( training_idxs, :, : );
    fidsTest = fids( test_idxs, :, : );
    
    % Set labels
    labelsTrain = LABELS_MATRIX( training_idxs, : );
    labelsTest = LABELS_MATRIX( test_idxs, : );

    %% NORMALIZE FEATURES
    % Must be done after we separate training and test set, otherwise at test
    % time we would be using information about the tested subjects.
    [fidsTrain, fidsTest] = ...
        normalizeFeatures( feature_norm, fidsTrain, fidsTest );
    
    %% TRAIN
    %Reshape fids so that they have N_IMAGES x 1
    fidsTrain = reshape( permute( fidsTrain, [1 3 2] ), ...
                         N_TRAIN_IMAGES, size( fidsTrain, 2 ) );
    fidsTest = reshape( permute( fidsTest, [1 3 2] ), ...
                         N_TEST_IMAGES, size( fidsTest, 2 ) );
    
    %Reshape labels so that they have N_IMAGES x 1
    labelsTrain = reshape( labelsTrain, N_TRAIN_IMAGES, 1 );
    labelsTest = reshape( labelsTest, N_TEST_IMAGES, 1 );
    
    [ W, resultsTrain, resultsTest ] = ...
        performRegression( fidsTrain, labelsTrain, fidsTest );
    
    %% ERROR DIAGNOSTICS
    errorTrain = median( abs( labelsTrain - resultsTrain ) );
    errorTest = median( abs( labelsTest - resultsTest ) );
    
    fprintf(['\n - Run number: [%i]/[%i]\n\t - Training Error = %.4f\n'...
           '\t - Test Error = %.4f\n'], s, N_RUNS, errorTrain, errorTest );
    
    singleRunStruct.numberIteration = s;
    singleRunStruct.fidsTrain = fidsTrain;
    singleRunStruct.N_SUBJ = N_SUBJ;
    singleRunStruct.N_MEASUREMENTS = N_MEASUREMENTS;
    singleRunStruct.N_PICS = N_PICS;
    singleRunStruct.labelsTrain = labelsTrain;
    singleRunStruct.fidsTest = fidsTest;
    singleRunStruct.labelsTest = labelsTest;
    singleRunStruct.weights = W;
    singleRunStruct.resultsTrain = resultsTrain;
    singleRunStruct.errorTrain = errorTrain;
    singleRunStruct.resultsTest = resultsTest;
    singleRunStruct.errorTest = errorTest;
    singleRunStruct.test_idxs=test_idxs;
    singleRunStruct.training_idxs=training_idxs;
    
    allCVRuns{s} = singleRunStruct;
    
end

%% SAVE RESULTS AND OUTPUT THEM FOR VISUALIZATION
save( [DINFO_PATH 'results.mat'], 'allCVRuns' ); 
out = allCVRuns;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%                       SELECT SUBJECT CATEGORIES                         %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function kept_subjects_idxs = removeSubjects( remove_subjects, infos )
% Create a vector containing the index of the subjects to keep for analysis

N_SUBJ = length(infos); 
kept_subjects_idxs=zeros(1,N_SUBJ); m=0;

switch remove_subjects
    case 'none'
        % keep every subject in collection
        kept_subjects_idxs = 1:N_SUBJ; m=N_SUBJ;
        
    case 'women'
        % keep only men
        for  s = 1:N_SUBJ
            if strcmp(infos{s}.subjGender,'male')
                m = m + 1;kept_subjects_idxs(m) = s;
            end
        end
    case 'men'
        % keep only women
        for  s = 1:N_SUBJ
            if strcmp(infos{s}.subjGender,'female')
                m = m + 1;kept_subjects_idxs(m) = s;
            end
        end
    case 'with_beard'
        % remove people with beard
        for  s = 1:N_SUBJ
            if infos{s}.hasBeard == 0
                m = m + 1;kept_subjects_idxs(m) = s;
            end
        end
    case 'occluded_ears'
        % remove people with occluded ears
        for  s = 1:N_SUBJ
            if infos{s}.visibleEars == 1
                m = m + 1; kept_subjects_idxs(m) = s;
            end
        end
end
kept_subjects_idxs=kept_subjects_idxs(1:m);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%                       SELECT NUMBER OF DISTANCES                        %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function kept_distances = selectDistanceNumber( distance_number )
switch distance_number
    case '3'
        kept_distances=[1 4 7];
        
    case '4'
        kept_distances=[1 3 5 7];
        
    case '5near'
        kept_distances=[1 2 3 5 7];
        
    case '5far'
        kept_distances=[1 3 5 6 7];
        
    case '7'
        kept_distances=1:7;
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%           SELECT INPUT ANNOTATION TYPE AND KEYPOINT GROUPS              %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function kept_fids_idxs=featureSelection( annotation_type, keypoint_group )

switch annotation_type
    case 'MANUAL_ST'
        num_keypoints = 110;
    case 'RCPR_CMDP_ST'
        num_keypoints = 110;
    case 'RCPR_300F_ST'
        num_keypoints = 136;
end
kept_fids_idxs = 1:num_keypoints;

groups = cell( 1, 9 );

if(num_keypoints==110)
    %CREATE FEATURE GROUPS ACCORDING TO MANUAL FIDUCIALS
    all=1:55;nfids=55;
    groups{1}=14:15;%mouth
    groups{2}=7:8;%leye
    groups{3}=9:10;%reye
    groups{4}=1:3;%leyebrow
    groups{5}=4:6;%reyebrow
    groups{6}=11:13;%nose
    groups{7}=18:42;%facial contour %16:42
    groups{8}=43:55;%head contour
    groups{9}=16:17;%ears
elseif(num_keypoints==136)
    %CREATE FEATURE GROUPS ACCORDING TO RCPR FIDUCIALS
    all=1:68;nfids=68;
    groups{1}=49:68;%mouth
    groups{2}=37:42;%leye
    groups{3}=43:48;%reye
    groups{4}=18:22;%leyebrow
    groups{5}=23:27;%reyebrow
    groups{6}=28:36;%nose
    groups{7}=1:18;%facial contour
    groups{8}=[];%head contour
    groups{9}=[];%ears
end

switch keypoint_group
    case 'all'
        %nothing to do
    case 'facial'
        %remove contours and ears
        kept_fids_idxs=removeGroup(all,sort([groups{7:9}]),nfids);
    case 'contour'
        %remove all facial and ears
        kept_fids_idxs=removeGroup(all,sort([groups{[1:6 9]}]),nfids);
    case 'fcontour'
        %remove all facial and head contour  and ears
        kept_fids_idxs=removeGroup(all,sort([groups{[1:6 8 9]}]),nfids);
    case 'hcontour'
        %remove all facial and facial contour  and ears
        kept_fids_idxs=removeGroup(all,sort([groups{[1:6 7 9]}]),nfids);
    case 'nose'
        %remove all ex nose
        kept_fids_idxs=removeGroup(all,sort([groups{[1:5 7:9]}]),nfids);
    case 'eyes'
        %remove all ex eyes+eyebrows
        kept_fids_idxs=removeGroup(all,sort([groups{[1 6:9]}]),nfids);
    case 'mouth'
        %remove all ex mouth
        kept_fids_idxs=removeGroup(all,sort([groups{2:9}]),nfids);
    case 'ears'
        %remove all ex ears
        kept_fids_idxs=removeGroup(all,sort([groups{1:8}]),nfids);
    case '-ears'
        %remove ears
        kept_fids_idxs=removeGroup(all,sort([groups{9}]),nfids);
    case 'f-eyebrows'
        %remove contour+eyebrows
        kept_fids_idxs=removeGroup(all,sort([groups{[4 5 7:9]}]),nfids);
    case 'f-eyes'
        %remove contour+eyes
        kept_fids_idxs=removeGroup(all,sort([groups{[2 3 7:9]}]),nfids);
    case 'f-nose'
        %remove contour+nose
        kept_fids_idxs=removeGroup(all,sort([groups{6:9}]),nfids);
    case 'f-mouth'
        %remove contour+mouth
        kept_fids_idxs=removeGroup(all,sort([groups{[1 7:9]}]),nfids);
    case 'c+eyebrows'
        %remove all ex eyebrows+contour
        kept_fids_idxs=removeGroup(all,sort([groups{[1:3 6 9]}]),nfids);
    case 'c+eyes'
        %remove all ex eyes+contour
        kept_fids_idxs=removeGroup(all,sort([groups{[1 4:6 9]}]),nfids);
    case 'c+nose'
        %remove all ex nose+contour
        kept_fids_idxs=removeGroup(all,sort([groups{[1:5 9]}]),nfids);
    case 'c+mouth'
        %remove all ex mouth+contour
        kept_fids_idxs=removeGroup(all,sort([groups{[2:6 9]}]),nfids);
    case '-eyebrows'
        %remove eyebrows
        kept_fids_idxs=removeGroup(all,sort([groups{4:5}]),nfids);
    case '-eyes'
        %remove eyes+eyebrows
        kept_fids_idxs=removeGroup(all,sort([groups{2:5}]),nfids);
    case '-eyes+fc'
        %remove eyes+eyebrows and fcontour
        kept_fids_idxs=removeGroup(all,sort([groups{[2:5 7]}]),nfids);
    case 'hc+nose'
        %remove eyes+eyebrows, fcontour and mouth ears
        kept_fids_idxs=removeGroup(all,sort([groups{[1:5 7 9]}]),nfids);
    case 'hc+mouth'
        %remove eyes+eyebrows, fcontour and nose ears
        kept_fids_idxs=removeGroup(all,sort([groups{[2:7 9]}]),nfids);
    case 'hc+ears'
        %remove eyes+eyebrows, fcontour and nose
        kept_fids_idxs=removeGroup(all,sort([groups{[1:7]}]),nfids);
    case 'fc+nose'
        %remove eyes+eyebrows, hcontour and nose
        kept_fids_idxs=removeGroup(all,sort([groups{[1:5 8 9]}]),nfids);
    case 'fc+ears'
        %remove eyes+eyebrows, hcontour and nose
        kept_fids_idxs=removeGroup(all,sort([groups{[1:6 8]}]),nfids);
    case 'fc+mouth'
        %remove eyes+eyebrows, hcontour and nose
        kept_fids_idxs=removeGroup(all,sort([groups{[2:6 8 9]}]),nfids);
    case 'fac+fc'
        %remove eyes+eyebrows, hcontour and nose
        kept_fids_idxs=removeGroup(all,sort([groups{[8 9]}]),nfids);
    case '-mouth'
        %remove mouth
        kept_fids_idxs=removeGroup(all,sort([groups{1}]),nfids);
end
end

function all = removeGroup( all, group, nfids )
    all = all(~ismember(all,group));
    all = [all all+nfids];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%                       NORMALIZE FEATURE VECTOR                          %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fidsTrain, fidsTest] = ...
            normalizeFeatures( feature_norm, fidsTrain, fidsTest )

N_SUBJ_TRAIN = size(fidsTrain,1);
N_SUBJ_TEST = size(fidsTest,1);
N_FIDS = size( fidsTrain, 2 ) / 2;
N_PICS = size( fidsTrain, 3 );

switch feature_norm
    case 'none'
        % nothing to be done
        
    case 'global_mean'
        % compute mean value for each feature over whole training set
        muX = mean( mean2( fidsTrain( :, 1:N_FIDS, : ) ) );
        muY = mean( mean2( fidsTrain(:, N_FIDS+1:end, : ) ) );
        
        % normalize training and test set with the same mean values 
        fidsTrain( :, 1:N_FIDS, : ) = fidsTrain( :, 1:N_FIDS, : ) - muX;
        fidsTrain( :, N_FIDS+1:end, : ) = ...
                                    fidsTrain( :, N_FIDS+1:end ,: ) - muY;
        
        fidsTest( :, 1:N_FIDS, : ) = fidsTest( :, 1:N_FIDS, : ) - muX;
        fidsTest( :, N_FIDS+1:end, : ) = ...
                                    fidsTest( :, N_FIDS+1:end, : ) - muY;
                                
    case 'subject_shape'
        for k = 1:N_SUBJ_TRAIN
            % compute mean value for each feature over single subject
            muX = mean2( fidsTrain( k, 1:N_FIDS, : ) );
            muY = mean2( fidsTrain( k, N_FIDS+1:end, : ) );
            
            % normalize that subject with its mean values
            fidsTrain( k, 1:N_FIDS, : )= fidsTrain( k, 1:N_FIDS, : ) - muX;
            fidsTrain( k, N_FIDS+1:end, : ) = ...
                                    fidsTrain( k, N_FIDS+1:end, : ) - muY;
        end
        
        for k = 1:N_SUBJ_TEST
            % compute mean value for each feature over single subject
            muX = mean2( fidsTest( k, 1:N_FIDS, : ) );
            muY = mean2( fidsTest( k, N_FIDS+1:end, : ) );
            
            % normalize that subject with its mean values
            fidsTest( k, 1:N_FIDS, : ) = fidsTest( k, 1:N_FIDS, : ) - muX;
            fidsTest( k, N_FIDS+1:end, : ) = ...
                                      fidsTest( k, N_FIDS+1:end, : ) - muY;
        end
        
    case 'distance_shape'
        % Add as feature the difference between the current landmarks and
        % the mean of landmarks at each of the possible distances
        muDX = zeros( N_PICS, N_FIDS );
        muDY = zeros( N_PICS, N_FIDS );
        
        for p = 1:N_PICS
            muDX( p, : ) = mean( fidsTrain( :, 1:N_FIDS, p ) );
            muDY( p, : ) = mean( fidsTrain( :, N_FIDS+1:end, p ) );
        end
        
        added_fidsTrain = zeros( N_SUBJ_TRAIN, N_FIDS*2*N_PICS, N_PICS );
        for k = 1:N_SUBJ_TRAIN
            for p1 = 1:N_PICS
                count = 1;
                for p2 = 1:N_PICS
                    added_fidsTrain( k, count:count+N_FIDS-1, p1 ) = ...
                        fidsTrain( k, 1:N_FIDS, p1 ) - muDX( p2 , : );
                    count = count + N_FIDS;
                    added_fidsTrain( k, count:count+N_FIDS-1 ) = ...
                        fidsTrain( k, N_FIDS+1:end, p1 ) - muDY( p2, : );
                    count = count + N_FIDS;
                end
            end
        end
        
        added_fidsTest = zeros( N_SUBJ_TEST, N_FIDS*2*N_PICS, N_PICS );
        for k = 1:N_SUBJ_TEST
            for p1 = 1:N_PICS
                count = 1;
                for p2 = 1:N_PICS
                    added_fidsTest( k, count:count+N_FIDS-1, p1 ) = ...
                            fidsTest( k, 1:N_FIDS, p1 ) - muDX( p2, : );
                    count = count + N_FIDS;
                    added_fidsTest( k, count:count+N_FIDS-1 ) = ...
                           fidsTest( k, N_FIDS+1:end, p1 ) - muDY( p2, : );
                    count = count + N_FIDS;
                end
            end
        end
        
        % normalize standard keypoint features before adding the new ones
        [fidsTrain, fidsTest] = ...
            normalizeFeatures( 'gloabl_mean', fidsTrain, fidsTest );
        
        % concatenate the two feature vectors
        fidsTrain = cat( 2, fidsTrain, added_fidsTrain );
        fidsTest = cat( 2, fidsTest, added_fidsTest ); 
        
end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%                       PERFORM REGRESSION ALGORITHM                      %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [ W, resultsTrain, resultsTest ] = ...
            performRegression( fidsTrain, labelsTrain, fidsTest )

    % perform simple linear regression
    % W = inv(fidsTrain' * fidsTrain) * fidsTrain' * labelsTrain;
    
    W = fidsTrain \ labelsTrain;
    resultsTrain = fidsTrain * W;
    resultsTest = fidsTest * W;
end