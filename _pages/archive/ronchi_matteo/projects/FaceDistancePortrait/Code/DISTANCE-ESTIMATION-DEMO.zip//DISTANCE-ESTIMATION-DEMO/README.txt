% Copyright (c) 2014:
%   - Xavier P.Burgos-Artizzu [xavier.burgos@technicolor.com]
%   - Matteo Ruggero Ronchi   [mronchi@caltech.edu]
%   - Pietro Perona           [perona@caltech.edu]
% Please email us if you find bugs, or have suggestions or questions!
% Licensed under the Simplified BSD License [see bsd.txt]

CONTENT OF THIS DIRECTORY:

- subjectDistance_demo.m: 

This script runs an experiment with the parameters provided as input, returns the results of experiment and visualizes them.

- performDistanceEstimation.m:

 This function runs an experiment with the parameters specificed by the user in the script specified above.

- bsd.txt:

License information for this code and the CMDP dataset.

INSTRUCTIONS TO RUN THIS CODE:

1) Make sure the paths in the dinfo.mat have been configured by running the script show_DINFO.m
2) Put the files subjectDistance_demo.m and performDistanceEstimation.m in the same directory as dinfo.mat
3) Run the script subjectDistance_demo.m
